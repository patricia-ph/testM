console.log("About");

// let aboutBtns = document.querySelectorAll('.sidebar ul li a');
// let aboutBlocks = document.querySelectorAll('.content .about-block');

// aboutBtns.forEach(function(item, i){
//   item.addEventListener('click', function(event){
//     event.preventDefault();
//     removePrevious(i);
//     item.classList.add("active");
//     aboutBlocks[i].classList.add("active");
//   });
// });

// let removePrevious = function(except){
//   aboutBtns.forEach(function(item, i){
//     if(i != except){
//       item.classList.remove("active");
//       aboutBlocks[i].classList.remove("active");
//     }
//   });
// }