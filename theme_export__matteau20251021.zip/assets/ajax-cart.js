let sideCartLoop = document.querySelector("#side-cart-loop");
let addToCartBtns = document.querySelectorAll("atc-btn");

for (let i = 0; i < addToCartBtns.length; i++) {
  addToCartBtns[i].addEventListener("click", function (event) {
    event.preventDefault();
    const formID = document.querySelector("#order-form").getAttribute("id");
    //console.log(formID);

    addProductToCart(formID);
  });
}

function addProductToCart(formID) {
  $.ajax({
    type: "POST",
    url: "/cart/add.js",
    dataType: "json",
    data: $("#" + formID).serialize(),
    success: addToCartOk,
    error: addToCartFail,
  });
}

function cartCount(cart){
  let cartCounters = document.querySelectorAll('.cart-count');
  let cartSubtotal = document.querySelectorAll('.cart-subtotal');
  var currencyCode = Shopify.currency.active;
  
  cartCounters.forEach(function(item){
    item.innerText = cart.item_count;
  });

  cartSubtotal.forEach(function (item) {
    item.innerText = Shopify.formatMoney(cart.total_price, "{{ amount_no_decimals }} " + currencyCode);
  });
}

function clearCart() {
  sideCartLoop.innerHTML = "";
}

function fetchCart() {
  $.ajax({
    type: "GET",
    url: "/cart.js",
    dataType: "json",
    success: function (cart) {
      if (cart.item_count === 0) {
        clearCart();
        cartCount(cart);
      } else {
        clearCart();
        renderCart(cart);
        cartCount(cart);
      }
    },
  });
}

function changeItem(line, callback) {
  const quantity = 0;
  $.ajax({
    type: "POST",
    url: "/cart/change.js",
    data: "quantity=" + quantity + "&line=" + line,
    dataType: "json",
    success: function (cart) {
      if (typeof callback === "function") {
        callback(cart);
      } else {
        fetchCart();
        cartCount(cart);
      }
    },
  });
}

function renderCart(cart) {
  //console.log(cart);
  cart.items.forEach(function (item, index) {
    //console.log(item);
    //var currency = Shopify.theme.currency;

    var currencyCode = Shopify.currency.active;
    let cleanPrice = Shopify.formatMoney(item.line_price, "{{ amount_no_decimals }} " + currencyCode);
    //let cleanPrice;
    //let cleanPrice = item.line_price;
    let productImage = '<a href="' + item.url + '"><img src="' + item.image + '" alt="Cart"></a>';
    let productTitle = '<a href="' + item.url + '" class="title">' + item.product_title + '</a>';

    let variantOne = "";
    let variantTwo = "";

    if(item.variant_options[0]){
      if(item.variant_options[0].length == 1){
        variantOne = '<span class="variant variant-size">Size ' + item.variant_options[0] + '</span>';
      } else {
        if (item.variant_options[0] == "Small" || item.variant_options[0] == "Medium" || item.variant_options[0] == "Large") {
          variantOne = '<span class="variant variant-color">Size ' + item.variant_options[0] + "</span>";
        } else {
          variantOne = '<span class="variant variant-color">' + item.variant_options[0] + "</span>";
        }
      }
    }

    if (item.variant_options[1]) {
      if (item.variant_options[1].length == 1) {
        variantTwo = '<span class="variant variant-size">Size ' + item.variant_options[1] + "</span>";
      } else {
        if (item.variant_options[0] == "Small" || item.variant_options[0] == "Medium" || item.variant_options[0] == "Large") {
          variantTwo = '<span class="variant variant-color">Size ' + item.variant_options[1] + "</span>";
        } else {
          variantTwo = '<span class="variant variant-color">' + item.variant_options[1] + "</span>";
        }
      }
    }

    let productPreOrder = '<span class="pre-order"></span>';     

    let productPrice = '<span class="price">' + cleanPrice + "</span>"; 
    let productRemove = '<a class="remove-btn" href="#">Remove</a>';

    let productItem = '<div class="item" data-line="' + Number(index + 1) + '"><div class="left">' + productImage + '</div><div class="right" href="' + item.url + '">' + productTitle + variantOne + variantTwo + productPrice + productPreOrder + productRemove + "</div>";

    sideCartLoop.innerHTML = sideCartLoop.innerHTML + productItem;

    let productHandle = "/products/" + item.handle + ".js";
    
    jQuery.getJSON(productHandle, function(product) {
      //console.log(product);
      let pTags = product.tags;
      pTags.forEach(function(tag,t){
        if(tag == "PRE-ORDER"){
          if(product.handle == 'the-low-back-slip-mini-dress-mojave' || product.handle == 'the-bandage-wrap-dress-black'){
            document.querySelectorAll('.items .item .pre-order')[index].innerText = "* Pre-order";
          } else {
            document.querySelectorAll('.items .item .pre-order')[index].innerText = "* Pre-order";
          }
        }
      });
    } );

  });

  removeFromCart = document.querySelectorAll('.remove-btn');

  for (let i = 0; i < removeFromCart.length; i++) {
    removeFromCart[i].addEventListener("click", function (event) {
      event.preventDefault();
      let line = this.parentNode.parentNode.getAttribute("data-line");
      //console.log(line);
      let currentIndexer = i;
      changeItem(line, currentIndexer);
    });
  }
}

document.addEventListener("DOMContentLoaded", function () {
  fetchCart();
});

//fetchCart();

//Cart
$(document).on("cart.ready", function (event, cart) {
  if (cart.item_count == 0) {
    $("#side-cart").addClass("empty");
    //$("#bag-btn").parent().addClass("hide");
  } else {
    //$("#bag-btn").parent().removeClass("hide");
    fetchCart();
  }
  //console.log(cart.item_count + " items in cart");
});


$(document).on("cart.requestComplete", function (event, cart) {
  if (cart.item_count == 0) {
    $("#side-cart").addClass("empty");
   //$("#bag-btn").parent().addClass("hide");
  } else if(cart.item_count == 1){
    location.reload();
    $("#side-cart").removeClass("empty");
    $("#side-cart").addClass("open");
    //$("#bag-btn").parent().removeClass("hide");
    fetchCart();
  } else {
    $("#side-cart").removeClass("empty");
    $("#side-cart").addClass("open");
    //$("#bag-btn").parent().removeClass("hide");
    fetchCart();
  }
});

