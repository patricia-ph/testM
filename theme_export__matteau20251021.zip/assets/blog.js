//Infinite Scroll
let nextBtn = document.querySelector("#paginate-next");

if (nextBtn) {
  var elem = document.querySelector(".journal-entries");
  var infScroll = new InfiniteScroll(elem, {
    // options
    path: "#paginate-next",
    append: ".entry",
    history: false,
  });

  infScroll.on("append", function () {
    console.log("Page added");
  });

  // infScroll.on("last", function () {
  //   document.querySelector(".paginate-link").classList.add("kill");
  // });
}
