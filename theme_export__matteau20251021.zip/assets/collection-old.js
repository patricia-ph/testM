console.log("Collections JS");

var controller = new ScrollMagic.Controller({});

// Logo
new ScrollMagic.Scene({
  triggerElement: ".container",
  triggerHook: 0,
  offset: -88,
})
  .setClassToggle("header", "black-logo")
  //.addIndicators({ name: "Logo", colorStart: "#A93226" })
  .addTo(controller);

// Nav
new ScrollMagic.Scene({
  triggerElement: ".container",
  triggerHook: 0,
  offset: -30,
})
  .setClassToggle("header", "black-nav")
  //.addIndicators({ name: "Nav", colorStart: "#E67E22" })
  .addTo(controller);

// Extra
// new ScrollMagic.Scene({
//   triggerElement: ".container",
//   triggerHook: 0,
//   offset: -88,
// })
// .setClassToggle("header", "black-logo")
// .addIndicators({ name: "Logo", colorStart: "#A93226" })
// .addTo(controller)
// .on("enter", function (event) {
//   document.querySelector('header').classList.remove("white");
// })
// .on("leave", function (event) {
//   document.querySelector('header').classList.add("white");
// });

// Products
//Get Colors
let getColors = function (theProducts) {
  //Short Sleeve Shirt - Mojave
  let productOne = [40069850890318, 40069850923086, 40069850923086, 40069850988622, 40069851021390];
  //Drawstring Trouser - Mojave
  let productTwo = [40069923504206, 40069923536974, 40069923569742, 40069923602510, 40069923635278];
  //Ribbed Tank - Black, Cacao, Ecru
  let productThree = [40069827133518, 40069827166286, 40069827199054, 40069827231822, 40069827264590, 40069827297358, 40069827330126, 40069827362894, 40069827395662, 40069827428430, 40069827461198, 40069827493966, 40069827526734, 40069827559502, 40069827592270];
  //Square Knit Dress - Black
  let productFour = [40069903188046, 40069903220814, 40069903253582, 40069903286350, 40069903319118];
  //Low Black Slip Mini Dress - Mojave
  let productFive = [40069900075086, 40069900107854, 40069900140622, 40069900173390, 40069900206158];
  //Relaxed Cargo Pant - White, Oregano
  let productSix = [40069823889486, 40069823922254, 40069823955022, 40069823987790, 40069824020558, 40069824053326, 40069824086094, 40069824118862, 40069824151630, 40069824184398];
  //Fisherman Pants - Black, White, Oregano
  let productSeven = [40069824413774, 40069824446542, 40069824479310, 40069824512078, 40069824544846, 40069824741454, 40069824774222, 40069824806990, 40069824839758, 40069824872526, 40069824577614, 40069824610382, 40069824643150, 40069824675918, 40069824708686];
  //Bandage Wrap Dress - Black
  let productEight = [40069840437326, 40069840470094, 40069840502862, 40069840535630, 40069840568398];
  //Utility Trousers - Black, White
  let productNine = [40069919342670, 40069919375438, 40069919408206, 40069919440974, 40069919473742, 40069919506510, 40069919539278, 40069919572046, 40069919604814, 40069919637582];
  //The Shirred Scoop Dress - Cinnamon
  let productTest = [39521792032846, 39521792065614, 39521792098382, 39521792131150, 39521792163918];

  let preOrderVariants = productOne.concat(productTwo, productThree, productFour, productFive, productSix, productSeven, productEight, productNine);

  //console.log(preOrderVariants);

  theProducts.forEach(function (item, i) {
    if (item.classList.contains("color-set") == false) {
      let colorWrap = item.querySelector(".colors");
      let productHandle = colorWrap.dataset.productHandle;
      //console.log(productHandle);
      let productPath = "/products/" + productHandle + ".js";
      jQuery.getJSON(productPath, function (product) {
        //console.log(product);
        //console.log(product.title);
        let productURL = product.url;
        let variantURL = productURL + "?variant=";
        let productImg = product.featured_image;
        let allVariants = product.variants;
        //console.log(product.title);
        //console.log(allVariants);
        let duplicateColors = [];

        let fullVariantOne = [];
        let fullVariantTwo = [];

        allVariants.forEach(function (jtem, j) {
          fullVariantOne.push(jtem.option1);
          fullVariantTwo.push(jtem.option2);
        });

        let colorSwitchOne = false;
        let colorSwitchTwo = false;

        let firstSizeCheck = fullVariantOne[0];

        if (firstSizeCheck.length > 0) {
          colorSwitchOne = true;
        } else {
          colorSwitchTwo = true;
        }

        allVariants.forEach(function (jtem, j) {
          duplicateColors.push(jtem.option1);
        });

        let singleColors = [...new Set(duplicateColors)];

        let defaultWrap = item.querySelectorAll(".swiper-slide img")[0];
        let defaultImage = item.querySelectorAll(".swiper-slide img")[0].src;
        let availWrap = item.querySelector(".availability");
        let defaultAvailability = item.querySelector(".availability").innerText.trim();

        singleColors.forEach(function (ktem, k) {
          let availableArray = [];

          let colorHandle = ktem
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, "-")
            .replace(/-$/, "")
            .replace(/^-/, "");
          let swatch = document.createElement("a");
          swatch.classList.add("single-color");
          //swatch.setAttribute("href", productURL);

          //console.log(product.title + " in " + ktem);

          let isPreOrderItem = false;

          if (colorSwitchOne) {
            allVariants.forEach(function (ltem, l) {
              console.log(ltem);

              if (ltem.option1 == ktem) {
                if (ltem.available) {
                  availableArray.push(ltem.option2);
                  let currentID = ltem.id;
                  if (preOrderVariants.includes(currentID)) {
                    //console.log("A pre-order item exists");
                    isPreOrderItem = true;
                  }
                  //console.log(ltem.options + " is available");
                } else {
                  //console.log(ltem.options + " is not available");
                }
              }

              let checkThis = ltem.option1;
              if (checkThis == ktem) {
                swatch.setAttribute("data-img", ltem.featured_image.src);
              }
              let dashColor = ktem.replace(/\s+/g, "-");
              let lowerColor = dashColor.toLowerCase();
              swatch.setAttribute("href", variantURL + lowerColor);
            });
          }

          if (colorSwitchTwo) {
            allVariants.forEach(function (ltem, l) {
              if (checkThis == ktem) {
                swatch.setAttribute("data-img", ltem.featured_image.src);
              }
              swatch.setAttribute("href", variantURL + ltem.id);
            });
          }

          let singleAvail = [...new Set(availableArray)];
          let sortAvail = singleAvail.sort(function (a, b) {
            return a - b;
          });
          let stringAvailable = sortAvail.join(", ");
          let finalAvail = "Availabie sizes: " + stringAvailable;

          //console.log(product.title + " in " + ktem + " " + finalAvail);
          console.log(isPreOrderItem);

          if (isPreOrderItem == true) {
            swatch.setAttribute("data-available", "Available for pre-order");
          } else {
            if (availableArray.length == 0) {
              swatch.setAttribute("data-available", "Sold Out");
            } else {
              swatch.setAttribute("data-available", finalAvail);
            }
          }

          swatch.setAttribute("data-name", ktem);

          let dot = document.createElement("span");
          dot.classList.add("swatch");
          dot.classList.add(colorHandle);

          swatch.append(dot);

          swatch.addEventListener("mouseenter", function () {
            defaultWrap.src = swatch.dataset.img;
            availWrap.innerText = swatch.dataset.available;
          });

          swatch.addEventListener("mouseleave", function () {
            defaultWrap.src = defaultImage;
            availWrap.innerText = defaultAvailability;
          });

          colorWrap.append(swatch);
        });
      });
      item.classList.add("color-set");
    }
  });
};

//Infinite Scroll
let nextBtn = document.querySelector("#paginate-next");

if (nextBtn) {
  var elem = document.querySelector(".loop");
  var infScroll = new InfiniteScroll(elem, {
    // options
    path: "#paginate-next",
    append: ".product",
    history: false,
  });

  infScroll.on("append", function () {
    let theProducts = document.querySelectorAll(".loop .product");
    console.log("Page added");
    getColors(theProducts);
  });

  // infScroll.on("last", function () {
  //   document.querySelector(".paginate-link").classList.add("kill");
  // });
}

window.addEventListener("load", (event) => {
  let swiper = new Swiper(".swiperino", {});
  let allProducts = document.querySelectorAll(".loop .product");
  getColors(allProducts);
});
