console.log("Collections JS");

var controller = new ScrollMagic.Controller({});

// Logo
new ScrollMagic.Scene({
  triggerElement: ".container",
  triggerHook: 0,
  //offset: -88,
  offset: -30,
})
  .setClassToggle("header", "black-logo")
  //.addIndicators({ name: "Logo", colorStart: "#A93226" })
  .addTo(controller);

// Nav
new ScrollMagic.Scene({
  triggerElement: ".container",
  triggerHook: 0,
  offset: -30,
})
  .setClassToggle("header", "black-nav")
  //.addIndicators({ name: "Nav", colorStart: "#E67E22" })
  .addTo(controller);

// Extra
// new ScrollMagic.Scene({
//   triggerElement: ".container",
//   triggerHook: 0,
//   offset: -88,
// })
// .setClassToggle("header", "black-logo")
// .addIndicators({ name: "Logo", colorStart: "#A93226" })
// .addTo(controller)
// .on("enter", function (event) {
//   document.querySelector('header').classList.remove("white");
// })
// .on("leave", function (event) {
//   document.querySelector('header').classList.add("white");
// });

// Products
//Get Colors
let getColors = function (theProducts) {
  theProducts.forEach(function (item, i) {
    if (item.classList.contains("color-set") == false) {
      let colorWrap = item.querySelector(".colors");
      let productHandle = colorWrap.dataset.productHandle;
      //console.log(productHandle);
      let productPath = "/products/" + productHandle + ".js";
      jQuery.getJSON(productPath, function (product) {
        //console.log(product);
        //console.log(product.title);
        let productURL = product.url;
        let variantURL = productURL;
        let productImg = product.featured_image;
        let allVariants = product.variants;
        //console.log(product.title);
        //console.log(allVariants);
        let duplicateColors = [];

        let fullVariantOne = [];
        let fullVariantTwo = [];

        allVariants.forEach(function (jtem, j) {
          fullVariantOne.push(jtem.option1);
          fullVariantTwo.push(jtem.option2);
        });

        let colorSwitchOne = false;
        let colorSwitchTwo = false;

        let firstSizeCheck = fullVariantOne[0];

        if (firstSizeCheck.length > 0) {
          colorSwitchOne = true;
        } else {
          colorSwitchTwo = true;
        }

        allVariants.forEach(function (jtem, j) {
          duplicateColors.push(jtem.option1);
        });

        let singleColors = [...new Set(duplicateColors)];

        let defaultWrap = item.querySelectorAll(".swiper-slide img")[0];
        let defaultImage = item.querySelectorAll(".swiper-slide img")[0].src;
        let availWrap = item.querySelector(".availability");
        let defaultAvailability = item.querySelector(".availability").innerText.trim();

        singleColors.forEach(function (ktem, k) {
          let availableArray = [];

          let colorHandle = ktem
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, "-")
            .replace(/-$/, "")
            .replace(/^-/, "");
          let swatch = document.createElement("a");
          swatch.classList.add("single-color");
          //swatch.setAttribute("href", productURL);

          //console.log(product.title + " in " + ktem);

          let isPreOrderItem = false;

          if (colorSwitchOne) {
            allVariants.forEach(function (ltem, l) {
              console.log(ltem);

              if (ltem.option1 == ktem) {
                if (ltem.available) {
                  availableArray.push(ltem.option2);
                  let currentID = ltem.id;
                  if (preOrderVariants.includes(currentID)) {
                    //console.log("A pre-order item exists");
                    isPreOrderItem = true;
                  }
                  //console.log(ltem.options + " is available");
                } else {
                  //console.log(ltem.options + " is not available");
                }
              }

              let checkThis = ltem.option1;
              if (checkThis == ktem) {
                swatch.setAttribute("data-img", ltem.featured_image.src);
              }
              let dashColor = ktem.replace(/\s+/g, "-");
              let lowerColor = dashColor.toLowerCase();
              swatch.setAttribute("href", variantURL + lowerColor);
            });
          }

          if (colorSwitchTwo) {
            allVariants.forEach(function (ltem, l) {
              if (checkThis == ktem) {
                swatch.setAttribute("data-img", ltem.featured_image.src);
              }
              swatch.setAttribute("href", variantURL + ltem.id);
            });
          }

          let singleAvail = [...new Set(availableArray)];
          let sortAvail = singleAvail.sort(function (a, b) {
            return a - b;
          });
          let stringAvailable = sortAvail.join(", ");
          let finalAvail = "Availabie sizes: " + stringAvailable;

          //console.log(product.title + " in " + ktem + " " + finalAvail);
          console.log(isPreOrderItem);

          if (isPreOrderItem == true) {
            swatch.setAttribute("data-available", "Available for pre-order");
          } else {
            if (availableArray.length == 0) {
              swatch.setAttribute("data-available", "Sold Out");
            } else {
              swatch.setAttribute("data-available", finalAvail);
            }
          }

          swatch.setAttribute("data-name", ktem);

          let dot = document.createElement("span");
          dot.classList.add("swatch");
          dot.classList.add(colorHandle);

          swatch.append(dot);

          swatch.addEventListener("mouseenter", function () {
            defaultWrap.src = swatch.dataset.img;
            availWrap.innerText = swatch.dataset.available;
          });

          swatch.addEventListener("mouseleave", function () {
            defaultWrap.src = defaultImage;
            availWrap.innerText = defaultAvailability;
          });

          colorWrap.append(swatch);
        });
      });
      item.classList.add("color-set");
    }
  });
};

//Mouse Over
let colorHover = function (theProducts) {
  theProducts.forEach(function (item, i) {
    if (item.classList.contains("color-set") == false) {
      let defaultImageWrap = item.querySelectorAll(".swiper-slide img")[0];
      let defaultImage = defaultImageWrap.src;
      let defaultAvailabilityWrap = item.querySelector(".availability");
      let defaultAvailability = defaultAvailabilityWrap.innerText;

      let getColors = item.querySelectorAll(".single-color");
      getColors.forEach(function (jtem, j) {
        jtem.addEventListener("mouseenter", function () {
          console.log(jtem.dataset.color);
          let removeSpaces = jtem.dataset.availability.trim();
          let removeBr = removeSpaces.replace(/[\r\n]/gm, "");

          defaultImageWrap.src = jtem.dataset.image;
          defaultAvailabilityWrap.innerText = removeBr;
        });

        jtem.addEventListener("mouseleave", function () {
          defaultImageWrap.src = defaultImage;
          defaultAvailabilityWrap.innerText = defaultAvailability;
        });
      });
      item.classList.add("color-set");
    }
  });
};

//Infinite Scroll
let nextBtn = document.querySelector("#paginate-next");

if (nextBtn) {
  var elem = document.querySelector(".loop");
  var infScroll = new InfiniteScroll(elem, {
    // options
    path: "#paginate-next",
    append: ".product",
    history: false,
  });

  infScroll.on("append", function () {
    let theProducts = document.querySelectorAll(".loop .product");
    console.log("Page added");
    //getColors(theProducts);
  });

  // infScroll.on("last", function () {
  //   document.querySelector(".paginate-link").classList.add("kill");
  // });
}

window.addEventListener("load", (event) => {
  let swiper = new Swiper(".swiperino", {});
  let allProducts = document.querySelectorAll(".loop .product");
  //getColors(allProducts);
  colorHover(allProducts);
});
