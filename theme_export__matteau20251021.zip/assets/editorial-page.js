console.log("Editorial Page JS");

let getHeaderColor = function (singlePage) {
  let color = singlePage.classList.contains("white-text");
  if (color) {
    document.querySelector("header").classList.add("white");
  } else {
    document.querySelector("header").classList.remove("white");
  }
};

let editorialWrap = document.querySelectorAll('.editorial-single-wrap');

editorialWrap.forEach(function(xtem){

  let getPages = xtem.querySelectorAll(".single-page");
  let pageLimit = getPages.length - 1;

  let pageCount = xtem.querySelectorAll(".editorial-count");

  getHeaderColor(getPages[0]);

  pageCount.forEach(function (atem) {
    atem.innerText = pageCount.length;
  });

  getPages.forEach(function (item, i) {
    let leftBtn = item.querySelector(".controls .left");
    let rightBtn = item.querySelector(".controls .right");

    if (i == 0) {
      leftBtn.addEventListener("click", function (event) {
        event.preventDefault();
        console.log("First page");
      });
    } else {
      leftBtn.addEventListener("click", function (event) {
        event.preventDefault();
        prevPage(i);
      });
    }

    if (i == pageLimit) {
      rightBtn.addEventListener("click", function (event) {
        event.preventDefault();
        console.log("Last page");
      });
    } else {
      rightBtn.addEventListener("click", function (event) {
        event.preventDefault();
        nextPage(i);
      });
    }
  });

  let nextPage = function (current) {
    let nextIndex = current + 1;
    getPages.forEach(function (item, i) {
      getPages[current].classList.remove("active");
      getPages[nextIndex].classList.add("active");
    });
    getHeaderColor(getPages[nextIndex]);
  };

  let prevPage = function (current) {
    let prevIndex = current - 1;
    getPages.forEach(function (item, i) {
      getPages[current].classList.remove("active");
      getPages[prevIndex].classList.add("active");
    });
    getHeaderColor(getPages[prevIndex]);
  };
});

let setDescMargin = function () {
  let pageWidth = document.querySelector("main").clientWidth;
  let leftMargin = pageWidth / 2 + 36;
  let rightDesc = document.querySelectorAll(".right-desc");

  rightDesc.forEach(function (item) {
    item.style.left = leftMargin + "px";
  });
};

setDescMargin();

window.addEventListener("resize", setDescMargin);
