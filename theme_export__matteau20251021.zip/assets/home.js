var controller = new ScrollMagic.Controller({});

// Logo
new ScrollMagic.Scene({
  triggerElement: ".double",
  triggerHook: 0,
  offset: -30,
})
  .setClassToggle("header", "white-logo")
  .addTo(controller);

// Nav
new ScrollMagic.Scene({
  triggerElement: ".double",
  triggerHook: 0,
  offset: -30,
})
  .setClassToggle("header", "white-nav")
  .addTo(controller);


function calcTime(offset, clock) {
  // create Date object for current location
  var d = new Date();

  // convert to msec
  // subtract local time zone offset
  // get UTC time in msec
  var utc = d.getTime() + d.getTimezoneOffset() * 60000;

  // create new Date object for different city
  // using supplied offset
  var nd = new Date(utc + 3600000 * offset);
  var hours = String(nd.getHours()).padStart(2, '0');
  var minutes = String(nd.getMinutes()).padStart(2, '0');

  clock.innerText = hours + ":" + minutes;

  // return time as a string
  //return "The local time for city" + city + " is " + nd.toLocaleString();
}

let sydneyClock = document.querySelector("#sydney-time");
let honoluluClock = document.querySelector("#honolulu-time");
let losAngelesClock = document.querySelector("#los-angeles-time");
let rioClock = document.querySelector("#rio-time");
let palmaClock = document.querySelector("#palma-time");
let cairoClock = document.querySelector("#cairo-time");

function setTimes(){
  calcTime("+11", sydneyClock);
  calcTime("-10", honoluluClock);
  calcTime("-7", losAngelesClock);
  calcTime("-3", rioClock);
  calcTime("+2", palmaClock);
  calcTime("+3", cairoClock);
}

setInterval(setTimes, 1000);

//alert(calcTime("Bombay", "+5.5"));

//Weather
// Declaring the variables
let lon;
let lat;
let temperature = document.querySelector(".temp");
let summary = document.querySelector(".summary");
let loc = document.querySelector(".location");
let icon = document.querySelector(".icon");
const kelvin = 273;

window.addEventListener("load", () => {
  const kelvin = 273;

	let api = "201d7190ccbc5ec32f4cc2ef3b6f763a";

  let sydCity = "2147714";
  let honCity = "5856195";
  let losCity = "5368361";
  let rioCity = "3451190";
  let palCity = "2512989";
  let caiCity = "360630";

	// API URL
	let sydney = "https://api.openweathermap.org/data/2.5/weather?id=" + sydCity + "&appid=" + api;
  let honolulu = "https://api.openweathermap.org/data/2.5/weather?id=" + honCity + "&appid=" + api;
  let losAngeles = "https://api.openweathermap.org/data/2.5/weather?id=" + losCity + "&appid=" + api;
  let rio = "https://api.openweathermap.org/data/2.5/weather?id=" + rioCity + "&appid=" + api;
  let palma = "https://api.openweathermap.org/data/2.5/weather?id=" + palCity + "&appid=" + api;
  let cairo = "https://api.openweathermap.org/data/2.5/weather?id=" + caiCity + "&appid=" + api;

  let sydTemp = document.querySelector("#sydney-temp");
  let honTemp = document.querySelector("#honolulu-temp");
  let losTemp = document.querySelector("#los-angeles-temp");
  let rioTemp = document.querySelector("#rio-temp");
  let palTemp = document.querySelector("#palma-temp");
  let caiTemp = document.querySelector("#cairo-temp");

	// Calling the API
	fetch(sydney).then((response) => {
		return response.json();
	}).then((data) => {
		console.log(data);
    let cee = Math.floor(data.main.temp - kelvin) + "°C";
    let eff = Math.floor(((data.main.temp - kelvin)*1.8)+32) + "°F";
    sydTemp.innerText = cee + " / " + eff;
	});

	fetch(honolulu).then((response) => {
		return response.json();
	}).then((data) => {
		console.log(data);
    let cee = Math.floor(data.main.temp - kelvin) + "°C";
    let eff = Math.floor(((data.main.temp - kelvin)*1.8)+32) + "°F";
    honTemp.innerText = cee + " / " + eff;
	});

	fetch(losAngeles).then((response) => {
		return response.json();
	}).then((data) => {
		console.log(data);
    let cee = Math.floor(data.main.temp - kelvin) + "°C";
    let eff = Math.floor(((data.main.temp - kelvin)*1.8)+32) + "°F";
    losTemp.innerText = cee + " / " + eff;
	});

	fetch(rio).then((response) => {
		return response.json();
	}).then((data) => {
		console.log(data);
    let cee = Math.floor(data.main.temp - kelvin) + "°C";
    let eff = Math.floor(((data.main.temp - kelvin)*1.8)+32) + "°F";
    rioTemp.innerText = cee + " / " + eff;
	});

	fetch(palma).then((response) => {
		return response.json();
	}).then((data) => {
		console.log(data);
    let cee = Math.floor(data.main.temp - kelvin) + "°C";
    let eff = Math.floor(((data.main.temp - kelvin)*1.8)+32) + "°F";
    palTemp.innerText = cee + " / " + eff;
	});

	fetch(cairo).then((response) => {
		return response.json();
	}).then((data) => {
		console.log(data);
    let cee = Math.floor(data.main.temp - kelvin) + "°C";
    let eff = Math.floor(((data.main.temp - kelvin)*1.8)+32) + "°F";
    caiTemp.innerText = cee + " / " + eff;
	});
});

