console.log("Main JS");

let items = document.querySelectorAll('.grid li .details');

items.forEach(function (item, i) {

  let title = item.querySelector('.title');
  let serviceList = item.querySelector('.service-list')

  title.addEventListener('click', function (event) {
    event.preventDefault();
    serviceList.classList.add('show');
  });

});

//Search
let searchBtn = document.querySelector("#search-btn");
let searchBar = document.querySelector("#search-bar");
let closeSearch = document.querySelector("#close-search-btn");
let searchHeader = document.querySelector('header');
let cartUrl = window.location.pathname;

console.log(cartUrl);

if(searchBar){
  searchBtn.addEventListener("click", function (event) {
    event.preventDefault();
    searchBar.classList.add("open");
    searchHeader.classList.add('temp-black');
    searchBar.querySelector(".text-form").focus();
  });

  closeSearch.addEventListener("click", function (event) {
    event.preventDefault();
    searchHeader.classList.remove("temp-black");
    searchBar.classList.remove("open");
  });
}

//Bag
let bagBtn = document.querySelector('#bag-btn');
let sideCart = document.querySelector('#side-cart');
let closeCart = document.querySelector('#close-cart-btn');

bagBtn.addEventListener('click', function (event) {
  console.log(cartUrl);
  event.preventDefault();
  if (cartUrl.includes("/cart")) {
  } else {
    sideCart.classList.toggle("open");
  }
});

closeCart.addEventListener("click", function (event) {
  event.preventDefault();
  sideCart.classList.remove("open");
});

//Navigation Menu Background Shift
let shopBtn = document.querySelector('#shop-dropdown');
let tempHeader = document.querySelector('header');

shopBtn.addEventListener('mouseenter', function () {
  tempHeader.classList.add('temp-black')
    $('.inner').attr('style','top: 0');
    $('#notifyD').attr('style','display: none');
    $('#notifyM').attr('style','display: none');
});

shopBtn.addEventListener("mouseleave", function () {
  tempHeader.classList.remove("temp-black");
});

//Mobile Nav and Cart Butttons
let mobileNavBtn = document.querySelector('#menu-btn');
let mobileNav = document.querySelector('.mobile-nav');
let cartBtn = document.querySelector('#cart-btn');
let menuBody = document.querySelector('body');

mobileNavBtn.addEventListener('click', function(event){
  event.preventDefault();
  document.querySelector('header').classList.toggle('mobile-nav-open');
  mobileNavBtn.classList.toggle("open");
  mobileNav.classList.toggle('open');
  menuBody.classList.toggle('no-scroll');
    $('.inner').attr('style','top: 0');
    $('#notifyD').attr('style','display: none');
    $('#notifyM').attr('style','display: none');
});

if(cartBtn){
  cartBtn.addEventListener("click", function (event) {
    event.preventDefault();
    if(cartUrl.includes("/cart")){

    } else {
      sideCart.classList.toggle("open");
    }
  });
}

//Checkout
let checkoutBtn = document.querySelector(".checkout-btn");
let checkoutURL = checkoutBtn.dataset.url;
let checkoutError = document.querySelector("#side-cart .cart-error");

checkoutBtn.addEventListener('click', function(event){
  event.preventDefault();
  let checkTerms = document.querySelector("#terms-check").checked;
  if (checkTerms) {
    window.location.href = checkoutURL + "/checkout";
  } else {
    //console.log("You must agree to the terms in order to proceed with checkout.");
    checkoutError.classList.add("show");
  }
});

//Mobile Nav Dropdowns
let gatherMenus = document.querySelectorAll('.first-menu .arrow');
let gatherDropBtns = document.querySelectorAll(".first-menu .drop-btn");

gatherMenus.forEach(function(item, i){
  item.addEventListener('click', function(event){
    event.preventDefault();
    item.parentNode.classList.toggle("open");
  });
});

gatherDropBtns.forEach(function (item, i) {
  item.addEventListener("click", function (event) {
    event.preventDefault();
    item.parentNode.classList.toggle("open");
  });
});

let cookiesPop = document.querySelector('#cookies-pop');
let closeCookies = cookiesPop.querySelector(".close-accept");
let cookiesError = cookiesPop.querySelector(".error-msg");

if(cookiesPop){
  //Cookies.set("cookieterms", "not-accepted", { expires: 3 });

  window.addEventListener("load", function () {
    let cookieTerms = Cookies.get("cookieterms");
    //console.log(cookieTerms);

    if (cookieTerms == "accepted") {
    } else {
      setTimeout(function () {
        cookiesPop.classList.add("active");
      }, 500);
    }
  });

  closeCookies.addEventListener("click", function (event) {
    event.preventDefault();
    Cookies.set("cookieterms", "accepted", { expires: 60 });
    cookiesPop.classList.remove("active");

  });
}

//Set Cart Height
window.addEventListener("load", function () {
  // let trueHeight = window.innerHeight;
  // sideCart.querySelector('.inner').style.height = trueHeight + "px";

  let trueHeight = window.innerHeight;
  let setHeights = document.querySelectorAll('.true-height');
  setHeights.forEach(function(item,i){
    item.style.height = trueHeight + "px";
  });
});

window.addEventListener("resize", function(){
  let trueHeight = window.innerHeight;
  let setHeights = document.querySelectorAll(".true-height");
  setHeights.forEach(function (item, i) {
    item.style.height = trueHeight + "px";
  });
});