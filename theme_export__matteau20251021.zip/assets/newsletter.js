let newsPop = document.querySelector("#news-pop");
let closeNews = document.querySelector("#close-news");

//Cookies.set('newscookie', 'not-active', { expires: 3 });

closeNews.addEventListener("click", function (event) {
  event.preventDefault();
  newsPop.classList.remove("appear");
  Cookies.set("newscookie", "active", { expires: 7 });
});

window.addEventListener("load", function () {
  let popCookie = Cookies.get("newscookie");
  //console.log(popCookie);

  if (popCookie == "active") {
  } else {
    setTimeout(function () {
      newsPop.classList.add("appear");
    }, 1000);
  }
});
