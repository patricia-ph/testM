window.addEventListener("load", function () {
  let currentURL = window.location.href;
  let containsVariant = currentURL.includes("?variant=");
  if (containsVariant) {
    let splitURL = currentURL.split("?variant=");
    let variantHandle = splitURL[1];
    //console.log(variantHandle);

    let colorSelector = '[data-handle="' + variantHandle + '"]';

    let colorWrapper = document.querySelector(colorSelector);
    //console.log(colorWrapper);
    colorWrapper.click();
  }
});
