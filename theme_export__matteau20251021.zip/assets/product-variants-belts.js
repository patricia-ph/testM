console.log("Belts");

let handle = document.querySelector(".variants").dataset.handle;
let productPath = "/products/" + handle + ".js";
jQuery.getJSON(productPath, function (product) {
  //console.log(product);

  let allVariants = product.variants;

  let fullVariantOne = [];
  let variantOne = [];

  allVariants.forEach(function (jtem, j) {
    variantOne.push(jtem.option1);
    fullVariantOne.push(jtem.option1);
  });
  // console.log(variantOne);
  // console.log(variantTwo);

  let singleVariantOne = [...new Set(variantOne)];

  //console.log("Size First");
  document.querySelectorAll(".variants .variant-wrap")[0].dataset.type = "size";
  document.querySelectorAll(".mobile-atc .variant-wrap")[0].dataset.type = "size";

  document.querySelectorAll(".variants .variant-wrap .label")[0].innerText = "Select Size";
  document.querySelectorAll(".mobile-atc .variant-wrap .label")[0].innerText = "Select Size";


  //console.log(singleVariantOne);
  //console.log(singleVariantTwo);

  let addPrevSelected = function (current) {
    let getAllDrops = document.querySelectorAll(".variants .variant-wrap .variant-con")[current];
    let mgetAllDrops = document.querySelectorAll(".mobile-atc .variant-wrap .variant-con")[current];
    let getAllOptions = getAllDrops.querySelectorAll("span");
    let mgetAllOptions = mgetAllDrops.querySelectorAll("span");

    getAllOptions.forEach(function (item, i) {
      item.classList.remove("hide");
    });
    mgetAllOptions.forEach(function (item, i) {
      item.classList.remove("hide");
    });
  };

  singleVariantOne.forEach(function (item, i) {
    let label = document.querySelectorAll(".variants .variant-wrap")[0].querySelector(".label");
    let mlabel = document.querySelectorAll(".mobile-atc .variant-wrap")[0].querySelector(".label");
    let option = document.createElement("div");
    let moption = document.createElement("div");
    let parentCon = document.querySelectorAll(".variants .variant-con")[0];
    let mparentCon = document.querySelectorAll(".mobile-atc .variant-con")[0];

    option.setAttribute("data-name", item);
    option.classList.add("option");
    option.classList.add("single-option");

    moption.setAttribute("data-name", item);
    moption.classList.add("option");
    moption.classList.add("single-option");

    option.innerText = item;
    moption.innerText = item;

    option.addEventListener("click", function () {
      //console.log(option.dataset.name);

      label.innerText = option.dataset.name;
      mlabel.innerText = option.dataset.name;

      let submitBtn = document.querySelector("#bag-submit-btn");
      let mobileSubmitBtn = document.querySelector("#mobile-atc-btn");
      submitBtn.dataset.selectedOne = option.dataset.name;
      mobileSubmitBtn.dataset.selectedOne = option.dataset.name;

      parentCon.classList.remove("show");
      mparentCon.classList.remove("show");
      addPrevSelected(0);
      option.classList.add("hide");

      if (submitBtn.dataset.selectedOne != "") {
        submitBtn.classList.remove("disabled");
        setButtonStatus();
      }
    });

    moption.addEventListener("click", function () {
      //console.log(option.dataset.name);

      label.innerText = option.dataset.name;
      mlabel.innerText = option.dataset.name;

      let submitBtn = document.querySelector("#bag-submit-btn");
      let mobileSubmitBtn = document.querySelector("#mobile-atc-btn");
      submitBtn.dataset.selectedOne = option.dataset.name;
      mobileSubmitBtn.dataset.selectedOne = option.dataset.name;

      parentCon.classList.remove("show");
      mparentCon.classList.remove("show");
      addPrevSelected(0);
      option.classList.add("hide");

      if (submitBtn.dataset.selectedOne != "") {
        submitBtn.classList.remove("disabled");
        setButtonStatus();
      }
    });

    parentCon.append(option);
    mparentCon.append(moption);
  });
});

//Submit
let atcBtn = document.querySelector("#bag-submit-btn");
let atcBtns = document.querySelectorAll(".atc-btn");

atcBtns.forEach(function(jtem, j){
  jtem.addEventListener("click", function (event) {
    event.preventDefault();

    let firsrtChoice = atcBtn.dataset.selectedOne;

    if (firsrtChoice) {
      //console.log(firsrtChoice + " + " + secondChoice);
      jQuery.getJSON(productPath, function (product) {
        let allVariants = product.variants;
        allVariants.forEach(function (item, i) {
          //console.log(item);
          if (item.option1 == firsrtChoice) {
            //console.log(item);
            //console.log("The index is " + i);
            //document.querySelector('#selected-variant').value = item.id;
            //document.querySelector('#order-form').submit();
            //console.log(document.querySelector("#selected-variant").value);
            if (item.available) {
              CartJS.addItem(item.id, 1);
            } else {
              console.log("This combination is sold out");
            }
          }
        });
      });
    } else {
      console.log("Please select an option");
    }

    //console.log("Add To Cart");
  });
})

//Set Button Status
let setButtonStatus = function(){
  let atcBtn = document.querySelector("#bag-submit-btn");
  let mobileatcBtn = document.querySelector("#mobile-atc-btn");

  let firsrtChoice = atcBtn.dataset.selectedOne;

  if (firsrtChoice) {
    //console.log(firsrtChoice);
    jQuery.getJSON(productPath, function (product) {
      let allVariants = product.variants;
      allVariants.forEach(function (item, i) {
        //console.log(item);
        if (item.option1 == firsrtChoice) {
          //console.log(item);
          if(item.available){
            atcBtn.innerText = "Add To Bag";
            mobileatcBtn.innerText = "Add To Bag";
          } else {
            atcBtn.innerText = "Sold Out";
            mobileatcBtn.innerText = "Sold Out";
          }
        }
      });
    });
  } else {
    //console.log("Please select an option");
  }
}