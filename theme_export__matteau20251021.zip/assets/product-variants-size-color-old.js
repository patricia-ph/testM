let handle = document.querySelector(".variants").dataset.handle;
let productPath = "/products/" + handle + ".js";
jQuery.getJSON(productPath, function (product) {
  //console.log(product);

  let allVariants = product.variants;
  //console.log(allVariants);

  let allImages = product.images;

  let fullVariantOne = [];
  let fullVariantTwo = [];
  let variantOne = [];
  let variantTwo = [];

  allVariants.forEach(function (jtem, j) {
    variantOne.push(jtem.option1);
    fullVariantOne.push(jtem.option1);

    variantTwo.push(jtem.option2);
    fullVariantTwo.push(jtem.option2);
  });
  // console.log(variantOne);
  // console.log(variantTwo);

  let singleVariantOne = [...new Set(variantOne)];
  let singleVariantTwo = [...new Set(variantTwo)];

  let colorSwitchOne = false;
  let colorSwitchTwo = false;

  let colorCheckOne = false;
  let colorCheckTwo = false;

  //console.log(allVariants);

  let firstSizeCheck = singleVariantOne[0];
  //console.log(singleVariantOne[0].length);

  if (firstSizeCheck.length > 1) {
    //console.log("Color First");
    document.querySelectorAll(".variants .variant-wrap")[0].dataset.type = "color";
    document.querySelectorAll(".variants .variant-wrap")[1].dataset.type = "size";
    document.querySelectorAll(".mobile-atc .variant-wrap")[0].dataset.type = "color";
    document.querySelectorAll(".mobile-atc .variant-wrap")[1].dataset.type = "size";

    document.querySelectorAll(".variants .variant-wrap .label")[0].innerText = "Select Color";
    document.querySelectorAll(".variants .variant-wrap .label")[1].innerText = "Select Size";
    document.querySelectorAll(".mobile-atc .variant-wrap .label")[0].innerText = "Select Color";
    document.querySelectorAll(".mobile-atc .variant-wrap .label")[1].innerText = "Select Size";

    document.querySelectorAll(".variants .variant-wrap")[1].classList.add("first-variant-wrap");
    document.querySelectorAll(".variants .variant-wrap")[0].classList.add("second-variant-wrap");
    document.querySelectorAll(".mobile-atc .variant-wrap")[1].classList.add("first-variant-wrap");
    document.querySelectorAll(".mobile-atc .variant-wrap")[0].classList.add("second-variant-wrap");

    colorCheckOne = true;
    colorSwitchOne = true;
  } else {
    //console.log("Size First");
    document.querySelectorAll(".variants .variant-wrap")[1].dataset.type = "color";
    document.querySelectorAll(".variants .variant-wrap")[0].dataset.type = "size";
    document.querySelectorAll(".mobile-atc .variant-wrap")[1].dataset.type = "color";
    document.querySelectorAll(".mobile-atc .variant-wrap")[0].dataset.type = "size";

    document.querySelectorAll(".variants .variant-wrap .label")[1].innerText = "Select Color";
    document.querySelectorAll(".variants .variant-wrap .label")[0].innerText = "Select Size";
    document.querySelectorAll(".mobile-atc .variant-wrap .label")[1].innerText = "Select Color";
    document.querySelectorAll(".mobile-atc .variant-wrap .label")[0].innerText = "Select Size";

    document.querySelectorAll(".variants .variant-wrap")[0].classList.add("first-variant-wrap");
    document.querySelectorAll(".variants .variant-wrap")[1].classList.add("second-variant-wrap");
    document.querySelectorAll(".mobile-atc .variant-wrap")[0].classList.add("first-variant-wrap");
    document.querySelectorAll(".mobile-atc .variant-wrap")[1].classList.add("second-variant-wrap");

    colorCheckTwo = true;
    colorSwitchTwo = true;
  }

  //console.log(singleVariantOne);
  //console.log(singleVariantTwo);

  let addPrevSelected = function (current) {
    let getAllDrops = document.querySelectorAll(".variants .variant-wrap .variant-con")[current];
    let mgetAllDrops = document.querySelectorAll(".mobile-atc .variant-wrap .variant-con")[current];
    let getAllOptions = getAllDrops.querySelectorAll("span");
    let mgetAllOptions = mgetAllDrops.querySelectorAll("span");

    getAllOptions.forEach(function (item, i) {
      item.classList.remove("hide");
    });
    mgetAllOptions.forEach(function (item, i) {
      item.classList.remove("hide");
    });
  };

  singleVariantOne.forEach(function (item, i) {
    //console.log(item);
    let label = document.querySelectorAll(".variants .variant-wrap")[0].querySelector(".label");
    let mlabel = document.querySelectorAll(".mobile-atc .variant-wrap")[0].querySelector(".label");
    let option = document.createElement("div");
    let moption = document.createElement("div");
    let parentCon = document.querySelectorAll(".variants .variant-con")[0];
    let mparentCon = document.querySelectorAll(".mobile-atc .variant-con")[0];

    let dashColor = item.replace(/\s+/g, "-");
    let lowerColor = dashColor.toLowerCase();

    option.setAttribute("data-name", item);
    option.setAttribute("data-handle", lowerColor);
    option.classList.add("option");
    option.classList.add("single-option");

    moption.setAttribute("data-name", item);
    moption.setAttribute("data-handle", lowerColor);
    moption.classList.add("option");
    moption.classList.add("single-option");

    if (colorCheckOne) {
      let colorText = document.createElement("span");
      let mcolorText = document.createElement("span");
      colorText.innerText = item;
      mcolorText.innerText = item;
      option.append(colorText);
      moption.append(mcolorText);

      let swatchWrap = document.createElement("span");
      let mswatchWrap = document.createElement("span");

      let swatch = document.createElement("i");
      let fullNameSwatch = option.dataset.name;
      let swatchHandle = fullNameSwatch
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/-$/, "")
        .replace(/^-/, "");
      swatch.classList.add("swatch");
      swatch.classList.add(swatchHandle);

      let mswatch = document.createElement("i");
      let mfullNameSwatch = moption.dataset.name;
      let mswatchHandle = mfullNameSwatch
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/-$/, "")
        .replace(/^-/, "");
      mswatch.classList.add("swatch");
      mswatch.classList.add(mswatchHandle);

      swatchWrap.appendChild(swatch);
      option.appendChild(swatchWrap);

      mswatchWrap.appendChild(mswatch);
      moption.appendChild(mswatchWrap);
    } else {
      option.innerText = item;
      moption.innerText = item;
    }

    option.addEventListener("click", function () {
      //console.log(option.dataset.name);

      if (colorCheckOne) {
        label.innerHTML = option.innerHTML;
        mlabel.innerText = option.dataset.name;
      } else {
        label.innerHTML = "Size " + option.innerHTML;
        mlabel.innerText = "Size " + option.dataset.name;
      }

      let submitBtn = document.querySelector("#bag-submit-btn");
      let mobileSubmitBtn = document.querySelector("#mobile-atc-btn");
      submitBtn.dataset.selectedOne = option.dataset.name;
      mobileSubmitBtn.dataset.selectedOne = option.dataset.name;

      parentCon.classList.remove("show");
      mparentCon.classList.remove("show");
      addPrevSelected(0);
      option.classList.add("hide");

      if (submitBtn.dataset.selectedOne != "" && submitBtn.dataset.selectedTwo != "") {
        submitBtn.classList.remove("disabled");
        setButtonStatus();
      }

      //Get Image
      let findThis = option.dataset.name.replace(/\s+/g, "-");

      if (colorSwitchOne) {
        setImages(findThis, allImages);
      }
    });

    moption.addEventListener("click", function () {
      //console.log(option.dataset.name);

      label.innerText = option.dataset.name;
      mlabel.innerText = option.dataset.name;

      let submitBtn = document.querySelector("#bag-submit-btn");
      let mobileSubmitBtn = document.querySelector("#mobile-atc-btn");
      submitBtn.dataset.selectedOne = option.dataset.name;
      mobileSubmitBtn.dataset.selectedOne = option.dataset.name;

      parentCon.classList.remove("show");
      mparentCon.classList.remove("show");
      addPrevSelected(0);
      option.classList.add("hide");

      if (submitBtn.dataset.selectedOne != "" && submitBtn.dataset.selectedTwo != "") {
        submitBtn.classList.remove("disabled");
        setButtonStatus();
      }

      //Get Image
      let findThis = option.dataset.name.replace(/\s+/g, "-");

      if (colorSwitchOne) {
        setImages(findThis, allImages);
      }
    });

    parentCon.append(option);
    mparentCon.append(moption);
  });

  singleVariantTwo.forEach(function (item, i) {
    let label = document.querySelectorAll(".variants .variant-wrap")[1].querySelector(".label");
    let mlabel = document.querySelectorAll(".mobile-atc .variant-wrap")[1].querySelector(".label");
    let option = document.createElement("div");
    let moption = document.createElement("div");
    let parentCon = document.querySelectorAll(".variants .variant-con")[1];
    let mparentCon = document.querySelectorAll(".mobile-atc .variant-con")[1];

    let dashColor = item.replace(/\s+/g, "-");
    let lowerColor = dashColor.toLowerCase();

    option.setAttribute("data-name", item);
    option.setAttribute("data-handle", lowerColor);
    option.classList.add("option");
    option.classList.add("single-option");

    moption.setAttribute("data-name", item);
    moption.setAttribute("data-handle", lowerColor);
    moption.classList.add("option");
    moption.classList.add("single-option");

    if (colorCheckTwo) {
      let colorText = document.createElement("span");
      let mcolorText = document.createElement("span");
      colorText.innerText = item;
      mcolorText.innerText = item;
      option.append(colorText);
      moption.append(mcolorText);

      let swatchWrap = document.createElement("span");
      let mswatchWrap = document.createElement("span");

      let swatch = document.createElement("i");
      let fullNameSwatch = option.dataset.name;
      let swatchHandle = fullNameSwatch
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/-$/, "")
        .replace(/^-/, "");
      swatch.classList.add("swatch");
      swatch.classList.add(swatchHandle);

      let mswatch = document.createElement("i");
      let mfullNameSwatch = moption.dataset.name;
      let mswatchHandle = mfullNameSwatch
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/-$/, "")
        .replace(/^-/, "");
      mswatch.classList.add("swatch");
      mswatch.classList.add(mswatchHandle);

      swatchWrap.appendChild(swatch);
      option.appendChild(swatchWrap);

      mswatchWrap.appendChild(mswatch);
      moption.appendChild(mswatchWrap);
    } else {
      option.innerText = item;
      moption.innerText = item;
    }

    option.addEventListener("click", function () {
      //console.log(option.dataset.name);

      if (colorCheckTwo) {
        label.innerHTML = option.innerHTML;
        mlabel.innerText = option.dataset.name;
      } else {
        label.innerHTML = "Size " + option.innerHTML;
        mlabel.innerText = "Size " + option.dataset.name;
      }

      let submitBtn = document.querySelector("#bag-submit-btn");
      let msubmitBtn = document.querySelector("#mobile-atc-btn");
      submitBtn.dataset.selectedTwo = option.dataset.name;
      msubmitBtn.dataset.selectedTwo = option.dataset.name;

      parentCon.classList.remove("show");
      mparentCon.classList.remove("show");
      addPrevSelected(1);
      option.classList.add("hide");

      if (submitBtn.dataset.selectedOne != "" && submitBtn.dataset.selectedTwo != "") {
        submitBtn.classList.remove("disabled");
        setButtonStatus();
      }
    });

    moption.addEventListener("click", function () {
      //console.log(option.dataset.name);

      label.innerText = option.dataset.name;
      mlabel.innerText = option.dataset.name;

      let submitBtn = document.querySelector("#bag-submit-btn");
      let msubmitBtn = document.querySelector("#mobile-atc-btn");
      submitBtn.dataset.selectedTwo = option.dataset.name;
      msubmitBtn.dataset.selectedTwo = option.dataset.name;

      parentCon.classList.remove("show");
      mparentCon.classList.remove("show");
      addPrevSelected(1);
      option.classList.add("hide");

      if (submitBtn.dataset.selectedOne != "" && submitBtn.dataset.selectedTwo != "") {
        submitBtn.classList.remove("disabled");
        setButtonStatus();
      }
    });

    parentCon.append(option);
    mparentCon.append(moption);

    //Get Image
    let findThis = option.dataset.name.replace(/\s+/g, "-");

    if (colorSwitchTwo) {
      setImages(findThis, allImages);
    }
  });
});

//Submit
let atcBtn = document.querySelector("#bag-submit-btn");
let atcBtns = document.querySelectorAll(".atc-btn");

atcBtns.forEach(function (jtem, j) {
  jtem.addEventListener("click", function (event) {
    event.preventDefault();

    let firsrtChoice = atcBtn.dataset.selectedOne;
    let secondChoice = atcBtn.dataset.selectedTwo;

    if (firsrtChoice && secondChoice) {
      //console.log(firsrtChoice + " + " + secondChoice);
      jQuery.getJSON(productPath, function (product) {
        let allVariants = product.variants;
        allVariants.forEach(function (item, i) {
          //console.log(item);
          if (item.option1 == firsrtChoice && item.option2 == secondChoice) {
            //console.log(item);
            //console.log("The index is " + i);
            //document.querySelector('#selected-variant').value = item.id;
            //document.querySelector('#order-form').submit();
            //console.log(document.querySelector("#selected-variant").value);
            if (item.available) {
              CartJS.addItem(item.id, 1);
            } else {
              console.log("This combination is sold out");
            }
          }
        });
      });
    } else {
      console.log("Please select an option");
    }

    //console.log("Add To Cart");
  });
});

//Set Button Status
let setButtonStatus = function () {
  let atcBtn = document.querySelector("#bag-submit-btn");
  let mobileatcBtn = document.querySelector("#mobile-atc-btn");

  let firsrtChoice = atcBtn.dataset.selectedOne;
  let secondChoice = atcBtn.dataset.selectedTwo;

  if (firsrtChoice && secondChoice) {
    //console.log(firsrtChoice + " + " + secondChoice);
    jQuery.getJSON(productPath, function (product) {
      let allVariants = product.variants;
      allVariants.forEach(function (item, i) {
        //console.log(item);
        if (item.option1 == firsrtChoice && item.option2 == secondChoice) {
          //console.log(item);
          if (item.available) {
            atcBtn.innerText = "Add To Bag";
            mobileatcBtn.innerText = "Add To Bag";
          } else {
            atcBtn.innerText = "Sold Out";
            mobileatcBtn.innerText = "Sold Out";
          }
        }
      });
    });
  } else {
    //console.log("Please select an option");
  }
};
