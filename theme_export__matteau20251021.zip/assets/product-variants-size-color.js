let handle = document.querySelector(".variants").dataset.handle;
let productPath = "/products/" + handle + ".js";

jQuery.getJSON(productPath, function (product) {
  //console.log(product);
  let allVariants = product.variants;
  //console.log(allVariants);

  let hideCurrentOption = function (current) {
    let getAllDrops = document.querySelectorAll(".variants .variant-wrap .variant-con")[0];
    let mgetAllDrops = document.querySelectorAll(".mobile-atc .variant-wrap .variant-con")[0];
    let getAllOptions = getAllDrops.querySelectorAll(".variant-option");
    let mgetAllOptions = mgetAllDrops.querySelectorAll("span");

    // getAllOptions.forEach(function (item, i) {
    //   if (i == current) {
    //     item.classList.add("hide");
    //   } else {
    //     item.classList.remove("hide");
    //   }
    // });

    getAllDrops.classList.remove("show");
    mgetAllDrops.classList.remove("show");

    // mgetAllOptions.forEach(function (item, i) {
    //   item.classList.remove("hide");
    // });
  };

  let label = document.querySelectorAll(".variants .variant-wrap")[0].querySelector(".label");
  let mlabel = document.querySelectorAll(".mobile-atc .variant-wrap")[0].querySelector(".label");

  let setButtons = function (status, variantID, variantName, productID) {
    if (status == "available") {
      let notifyBtns = document.querySelectorAll(".notify-btn");

      notifyBtns.forEach(function (ktem) {
        ktem.classList.add("hide");
      });

      let atcBtns = document.querySelectorAll(".atc-btn");
      atcBtns.forEach(function (ktem) {
        ktem.classList.remove("hide");
      });

      document.querySelector("#ajax-add-to-cart").removeAttribute("disabled");
      document.querySelector("#ajax-mobile-add-to-cart").removeAttribute("disabled");
    } else {
      let submitNotifyBtn = document.querySelector("#submit-notify");
      submitNotifyBtn.dataset.variantId = variantID;
      submitNotifyBtn.dataset.variantName = variantName;
      submitNotifyBtn.dataset.productId = productID;
      document.querySelector("#notify-size").innerHTML = variantName;

      let atcBtns = document.querySelectorAll(".atc-btn");

      atcBtns.forEach(function (ktem) {
        ktem.classList.add("hide");
      });

      let notifyBtns = document.querySelectorAll(".notify-btn");
      notifyBtns.forEach(function (ktem) {
        ktem.classList.remove("hide");
      });
    }
  };
          
  let submitStockButton = document.querySelector('#submit-notify');

  submitStockButton.addEventListener('click', function(event){
    event.preventDefault();

    let notifyEmail = document.querySelector("#notify-user-email").value;
    let producID = submitStockButton.dataset.productId;
    let variantID = submitStockButton.dataset.variantId;

    console.log("Email: " + notifyEmail + " Product ID: " + producID + " Variant ID: " + variantID);

    if (notifyEmail != "") {
const payload = {
  "data": {
    "type": "back-in-stock-subscription",
    "attributes": {
      "profile": {
        "data": {
            "type": "profile",
            "attributes": {
                "email": notifyEmail,
            }
        }
      },
      "channels": ["EMAIL"],
    },
    "relationships": {
      "variant": {
        "data": {
          "type": "catalog-variant",
          "id": "$shopify:::$default:::" +variantID
        }
      }
    }
  }
}

var requestOptions = {
    method: 'POST',
    headers: {
      "Content-Type": "application/json",
      "revision":"2024-06-15"
    },
    body: JSON.stringify(payload),
};

fetch("https://a.klaviyo.com/client/back-in-stock-subscriptions/?company_id=KQQbUH",requestOptions)
    .then(res => res.json())
  .then(json => console.log(json));
  document.querySelector("#stock-email").classList.add("hide");
  document.querySelector("#stock-success").classList.remove("hide");
  //.catch(err => console.error('error:' + err));

    }
  });

  let variantDropdown = document.querySelectorAll('.first-variant-wrap');

  variantDropdown.forEach(function(item){
    let options = item.querySelectorAll('.variant-option');
    options.forEach(function(jtem,j){

      jtem.addEventListener("click", function () {
        let variantID = jtem.dataset.id;
        let variantName = jtem.innerText;
        let productID = jtem.dataset.productId;

        document.querySelector("#selected-variant").value = jtem.dataset.id;
        document.querySelector("#ajax-add-to-cart").dataset.cartAdd = jtem.dataset.id;
        document.querySelector("#ajax-mobile-add-to-cart").dataset.cartAdd = jtem.dataset.id;

      
        label.innerText = "Size " + variantName;
        mlabel.innerText = "Size " + variantName;
      

        hideCurrentOption(j);

        allVariants.forEach(function (ktem) {
          if (ktem.id == variantID) {
            if (ktem.available) {
              setButtons("available");
            } else {
              setButtons("not-available", variantID, variantName, productID);
            }
          }
        });
      });

    });
  });

});
