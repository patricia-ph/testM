console.log("Product JS");

//Product Images Swiper
window.addEventListener("load", function () {
  var swiper = new Swiper(".product-swiper", {
    //autoHeight: true,
    //loop: true,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
  });

  var swiperTwo = new Swiper(".swiperino", {
    //autoHeight: true,
    //loop: true,
  });
});

//Variants
//Split into product-variants-x.js

// Style With Colors
let styleCheck = document.querySelector(".style-with");

if (styleCheck) {
  let allProducts = document.querySelectorAll(".loop .product");
  allProducts.forEach(function (item, i) {
    let colorWrap = item.querySelector(".colors");
    let productHandle = colorWrap.dataset.productHandle;
    let productPath = "/products/" + productHandle + ".js";

    jQuery.getJSON(productPath, function (product) {
      //console.log(product);
      let productURL = product.url;
      let productImg = product.featured_image;
      let allVariants = product.variants;
      let duplicateColors = [];

      allVariants.forEach(function (jtem, j) {
        duplicateColors.push(jtem.option1);
      });

      let singleColors = [...new Set(duplicateColors)];

      singleColors.forEach(function (ktem, k) {
        let colorHandle = ktem
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/-$/, "")
          .replace(/^-/, "");
        let swatch = document.createElement("a");
        swatch.classList.add("single-color");
        swatch.setAttribute("href", productURL);
        swatch.setAttribute("data-img", productImg);

        let dot = document.createElement("span");
        dot.classList.add(colorHandle);

        swatch.append(dot);

        colorWrap.append(swatch);
      });
    });
  });
}

//Dropdown Toggle
let dropdowns = document.querySelectorAll(".variants .variant-wrap");

dropdowns.forEach(function (ktem, k) {
  let btn = ktem.querySelector(".label");
  let drop = ktem.querySelector(".variant-con");
  btn.addEventListener("click", function () {
    closeOther(k);
    drop.classList.toggle("show");
  });
});

//Mobile Dropdown Toggle
let mdropdowns = document.querySelectorAll(".mobile-atc .variant-wrap");

mdropdowns.forEach(function (item, i) {
  let btn = item.querySelector(".label");
  let drop = item.querySelector(".variant-con");
  btn.addEventListener("click", function () {
    closeOther(i);
    drop.classList.toggle("show");
  });
});

let closeOther = function (other) {
  //console.log("Close Other Start");
  let dropdowns = document.querySelectorAll(".variants .variant-wrap");
  let mdropdowns = document.querySelectorAll(".mobile-atc .variant-wrap");
  dropdowns.forEach(function (item, i) {
    if (other == i) {
    } else {
      item.querySelector(".variant-con").classList.remove("show");
    }
  });

  mdropdowns.forEach(function (item, i) {
    if (other == i) {
    } else {
      item.querySelector(".variant-con").classList.remove("show");
    }
  });

  //console.log("Close Other End");
};

//Product Description
let fullDescWrap = document.querySelector(".information .desc");
let fullDesc = fullDescWrap.innerHTML;

let sizeCon = document.querySelector("#size-desc");
let materialsCon = document.querySelector("#materials-desc");

let splitDesc = fullDesc.split("<!-- split -->");
let mainDesc = splitDesc[0];
let materialsDesc = splitDesc[1];
let sizeDesc = splitDesc[2];

fullDescWrap.innerHTML = mainDesc;
//materialsCon.innerHTML = materialsDesc;
//sizeCon.innerHTML = sizeDesc;

//Bottom Products
let rvBtn = document.querySelector("#recent-btn");
let alBtn = document.querySelector("#also-like-btn");

let rvProducts = document.querySelector("#recently-viewed");
let alProducts = document.querySelector("#you-may-also-like");

rvBtn.addEventListener("click", function (event) {
  event.preventDefault();
  alBtn.classList.remove("active");
  alProducts.classList.remove("active");

  rvBtn.classList.add("active");
  rvProducts.classList.add("active");
});

alBtn.addEventListener("click", function (event) {
  event.preventDefault();
  rvBtn.classList.remove("active");
  rvProducts.classList.remove("active");

  alBtn.classList.add("active");
  alProducts.classList.add("active");
});

//Size Guide
let sbBtn = document.querySelector("#size-guide-btn");
let sgChart = document.querySelector("#side-size-guide");
let sgClose = document.querySelector("#close-size-btn");

if (sbBtn) {
  sbBtn.addEventListener("click", function (event) {
    event.preventDefault();
    sgChart.classList.add("open");
  });
}

sgClose.addEventListener("click", function (event) {
  event.preventDefault();
  sgChart.classList.remove("open");
});

//Sustainability Features
let sbBtnSF = document.querySelector("#sustainability-features-btn");
let sgChartSF = document.querySelector("#side-sustainability-features");
let sgCloseSF = document.querySelector("#close-sus-btn");

if (sbBtnSF) {
  sbBtnSF.addEventListener("click", function (event) {
    event.preventDefault();
    sgChartSF.classList.add("open");
  });
}

sgCloseSF.addEventListener("click", function (event) {
  event.preventDefault();
  sgChartSF.classList.remove("open");
});

let colorHover = function (theProducts) {
  theProducts.forEach(function (item, i) {
    let defaultImageWrap = item.querySelectorAll(".swiper-slide img")[0];
    let defaultImage = defaultImageWrap.src;
    //let defaultAvailabilityWrap = item.querySelector(".availability");
    //let defaultAvailability = defaultAvailabilityWrap.innerText;

    let getColors = item.querySelectorAll(".single-color");
    getColors.forEach(function (jtem, j) {
      jtem.addEventListener("mouseenter", function () {
        console.log(jtem.dataset.color);
        let removeSpaces = jtem.dataset.availability.trim();
        let removeBr = removeSpaces.replace(/[\r\n]/gm, "");

        defaultImageWrap.src = jtem.dataset.image;
        //defaultAvailabilityWrap.innerText = removeBr;
      });

      jtem.addEventListener("mouseleave", function () {
        defaultImageWrap.src = defaultImage;
        //defaultAvailabilityWrap.innerText = defaultAvailability;
      });
    });
  });
};

let firstProductViewed = function () {
  let rvProducts = document.querySelector("#recently-viewed");
  let alProducts = document.querySelector("#you-may-also-like");

  rvBtn.classList.add("remove");
  rvProducts.classList.remove("active");

  alBtn.classList.add("active");
  alProducts.classList.add("active");
};

let cleanTitle = function (theProducts) {
  theProducts.forEach(function (item, i) {
    let titleCon = item.querySelector(".title");
    let fullTitle = titleCon.innerText;
    let removeThe = fullTitle.replace("The ", "");
    let removeColor = removeThe.split(" - ");
    titleCon.innerText = removeColor[0];
  });
};

window.addEventListener("load", function () {
  let recentProducts = document.querySelectorAll("#recently-viewed-products .product");
  let ymalProducts = document.querySelectorAll("#the-product-recs .product");

  let rvCount = recentProducts.length;

  console.log(rvCount + " recently viewed products");
  console.log(ymalProducts.length + " YMALproducts");

  if (rvCount == 1) {
    firstProductViewed();
    colorHover(ymalProducts);
  } else {
    cleanTitle(recentProducts);
    colorHover(recentProducts);
    colorHover(ymalProducts);
  }
});

let removeArrow = document.querySelectorAll(".second-variant-wrap .variant-con .option");
if (removeArrow.length == 0) {
  document.querySelector(".second-variant-wrap").classList.add("remove-arrow");
}

// Back in Stock
let notifyBtn = document.querySelectorAll('.notify-btn');
let notifyForm = document.querySelector(".back-in-stock-widget");
let closeNotify = document.querySelectorAll('.close-notify');

notifyBtn.forEach(function(ktem){
  ktem.addEventListener("click", function (event) {
    event.preventDefault();
    notifyForm.classList.add("open");
  });
});

closeNotify.forEach(function(item){
  item.addEventListener('click', function(event){
    event.preventDefault();
    notifyForm.classList.remove('open');
  });
}); 