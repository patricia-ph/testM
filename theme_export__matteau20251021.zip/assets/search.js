console.log("Search JS");

// Colors
let allProducts = document.querySelectorAll(".loop .product");

if (allProducts.length > 1) {
  allProducts.forEach(function (item, i) {
    let colorWrap = item.querySelector(".colors");
    let productHandle = colorWrap.dataset.productHandle;
    //console.log(productHandle);
    let productPath = "/products/" + productHandle + ".js";
    jQuery.getJSON(productPath, function (product) {
      //console.log(product);
      //console.log(product.title);
      let productURL = product.url;
      let productImg = product.featured_image;
      let allVariants = product.variants;
      let duplicateColors = [];

      let fullVariantOne = [];
      let fullVariantTwo = [];

      allVariants.forEach(function (jtem, j) {
        fullVariantOne.push(jtem.option1);
        fullVariantTwo.push(jtem.option2);
      });

      let colorSwitchOne = false;
      let colorSwitchTwo = false;

      let firstSizeCheck = fullVariantOne[0];

      if (firstSizeCheck.length > 0) {
        colorSwitchOne = true;
      } else {
        colorSwitchTwo = true;
      }

      allVariants.forEach(function (jtem, j) {
        duplicateColors.push(jtem.option1);
      });

      let singleColors = [...new Set(duplicateColors)];

      let defaultWrap = item.querySelector(".first-img");
      let defaultImage = defaultWrap.src;

      singleColors.forEach(function (ktem, k) {
        let colorHandle = ktem
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/-$/, "")
          .replace(/^-/, "");
        let swatch = document.createElement("a");
        swatch.classList.add("single-color");
        swatch.setAttribute("href", productURL);

        if (colorSwitchOne) {
          allVariants.forEach(function (ltem, l) {
            let checkThis = ltem.option1;
            if (checkThis == ktem) {
              swatch.setAttribute("data-img", ltem.featured_image.src);
            }
          });
        }

        if (colorSwitchTwo) {
          allVariants.forEach(function (ltem, l) {
            let checkThis = ltem.option2;
            if (checkThis == ktem) {
              swatch.setAttribute("data-img", ltem.featured_image.src);
            }
          });
        }

        swatch.setAttribute("data-name", ktem);

        let dot = document.createElement("span");
        dot.classList.add(colorHandle);

        swatch.append(dot);

        swatch.addEventListener("mouseenter", function () {
          defaultWrap.src = swatch.dataset.img;
        });

        swatch.addEventListener("mouseleave", function () {
          defaultWrap.src = defaultImage;
        });

        colorWrap.append(swatch);
      });
    });
  });
}
