//Defaults
const defaults = {
  cartDrawer: ".js-ajax-cart-drawer", // classname
  cartDrawerContent: ".cart-loop", // classname
  cartDrawerContentPage: ".js-ajax-cart-drawer-content-page", // classname
  cartDrawerTrigger: ".js-ajax-cart-drawer-trigger", // classname
  removeFromCart: ".remove-btn", //classname
  addLineItem: ".add-btn", //classname
  removeLineItem: ".subtract-btn", //classname
};

const cartDrawer = document.querySelector(defaults.cartDrawer);
const cartDrawerContent = document.querySelector(defaults.cartDrawerContent);
const cartDrawerContentPage = document.querySelector(defaults.cartDrawerContentPage);
const cartDrawerTrigger = document.querySelector(defaults.cartDrawerTrigger);
let removeFromCart = document.querySelectorAll(defaults.removeFromCart);
let addLineItem = document.querySelectorAll(defaults.addLineItem);
let removeLineItem = document.querySelectorAll(defaults.removeLineItem);
const htmlSelector = document.documentElement;

//Title Case
function titleCase(str) {
  str = str.toLowerCase().split(" ");
  for (var i = 0; i < str.length; i++) {
    str[i] = str[i].charAt(0).toUpperCase() + str[i].slice(1);
  }
  return str.join(" ");
}

//Clear Cart
const clearCart = function () {
  cartDrawerContent.innerHTML = "";
};

//Display Cart in Side Cart
const displayCart = function () {
  $.ajax({
    type: "GET",
    url: "/cart.js",
    dataType: "json",
    success: function (cart) {
      //onCartUpdate(cart);

      if (cart.item_count === 0) {
        //console.log('Cart is empty');
        updateSubtotal();

        document.querySelector("#side-cart").classList.remove("open");

        if ($(".cart-page-loop").length) {
          updateSubtotalCartPage();
          document.querySelector(defaultsCartPage.cartPageCounter).innerHTML = cart.item_count;
        }
      } else {
        renderCart(cart);
        updateSubtotal();
        if ($(".cart-page-loop").length) {
          clearCartPage();
          renderCartPage(cart);
          updateSubtotalCartPage();
          document.querySelector(defaultsCartPage.cartPageCounter).innerHTML = cart.item_count;
        }
        //onsole.log('Cart has items');
      }
    },
  });
};

//Change Quantity
const changeItem = function (line, callback) {
  const quantity = 0;
  $.ajax({
    type: "POST",
    url: "/cart/change.js",
    data: "quantity=" + quantity + "&line=" + line,
    dataType: "json",
    success: function (cart) {
      if (typeof callback === "function") {
        //console.log("Callback");
        callback(cart);
      } else {
        //console.log("fetcher");
        //onCartUpdate(cart);
        //console.log("Line= " + line + " and Callback= " + callback);
        clearCart();
        displayCart();
        updateSubtotal();
      }
    },
  });
};

//Add One Item
const addOneItem = function (line, qty, location) {
  let addNewQty = qty + 1;
  $.ajax({
    type: "POST",
    url: "/cart/change.js",
    data: "quantity=" + addNewQty + "&line=" + line,
    dataType: "json",
    success: function (cart) {
      if (typeof callback === "function") {
        //console.log("Callback");
        callback(cart);
      } else {
        //console.log("Adder");
        //onCartUpdate(cart);

        // clearCart();
        // displayCart();
        updateSubtotal();
        document.querySelectorAll(".ajax-cart-drawer__content li")[location].dataset.qty = addNewQty;
        renderQuantities(cart, location);
      }
    },
  });
};

//Remove One Item
const subtractOneItem = function (line, qty, location) {
  let subNewQty = qty - 1;
  $.ajax({
    type: "POST",
    url: "/cart/change.js",
    data: "quantity=" + subNewQty + "&line=" + line,
    dataType: "json",
    success: function (cart) {
      if (typeof callback === "function") {
        //console.log("Callback");
        callback(cart);
      } else {
        //console.log("Remover");
        //onCartUpdate(cart);

        // clearCart();
        // displayCart();
        updateSubtotal();
        document.querySelectorAll(".ajax-cart-drawer__content li")[location].dataset.qty = subNewQty;
        renderQuantities(cart, location);
      }
    },
  });
};

//Render Cart
const renderCart = function (cart) {
  cart.items.forEach(function (item, index) {
    //console.log(item.variant_id);
    console.log(item);
    let dirtyHandle = item.handle;

    let title = '<span class="title">' + item.product_title + '</span>';
    let variantWrap = '<span class="variants"></span>';
    let dirtyPrice = item.line_price;
    let roundedPrice = dirtyPrice / 100;
    let formatPrice = roundedPrice.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
    let price = '<span class="price">$' + formatPrice + '</span>';
    let pRemove = '<a class="remove-btn" href="#">Remove</a>';

    let productItem = '<li class="item" data-line="' + Number(index + 1) + '" data-qty="' + item.quantity + '">' + '<a href="' + item.url + '" class="left">' + title + variantWrap + price + '</a>' + pRemove + '</li>';

    cartDrawerContent.innerHTML = cartDrawerContent.innerHTML + productItem;

    //console.log(item.options_with_values);

    let allVariants = item.options_with_values;
    let variantsWrap = document.querySelectorAll("#side-cart .variants")[index];

    allVariants.forEach(function (tag, j) {
      //console.log(tag.name + ' ' + tag.value);

      let cleanTagName = titleCase(tag.name);
      let cleanValueName = titleCase(tag.value);

      if (cleanTagName == "Title") {
        variantsWrap.classList.add("remove-item");
      } else {
        let singleVariant = "<span>" + cleanTagName + ": " + cleanValueName + "</span>";
        variantsWrap.innerHTML = variantsWrap.innerHTML + singleVariant;
      }
    });
  });

  //Remove
  document.querySelectorAll(".remove-btn").forEach((element) => {
    element.addEventListener("click", function () {
      const lineID = this.parentNode.getAttribute("data-line");
      //console.log('aa');
    });
  });

  removeFromCart = document.querySelectorAll(defaults.removeFromCart);

  for (let i = 0; i < removeFromCart.length; i++) {
    removeFromCart[i].addEventListener("click", function (event) {
      event.preventDefault();
      const line = this.parentNode.parentNode.getAttribute("data-line");
      //console.log(line);
      let currentIndexer = i;
      changeItem(line, currentIndexer);
    });
  }

  //Add or Subtract
  addLineItem = document.querySelectorAll(defaults.addLineItem);

  for (let i = 0; i < addLineItem.length; i++) {
    addLineItem[i].addEventListener("click", function () {
      let linez = this.parentNode.parentNode.parentNode.getAttribute("data-line");
      let lineQTY = parseInt(this.parentNode.parentNode.parentNode.getAttribute("data-qty"));
      let currentIndexer = i;
      //console.log(linez + lineQTY);
      addOneItem(linez, lineQTY, currentIndexer);
    });
  }

  //Subtract
  removeLineItem = document.querySelectorAll(defaults.removeLineItem);

  for (let i = 0; i < addLineItem.length; i++) {
    removeLineItem[i].addEventListener("click", function () {
      let linez = this.parentNode.parentNode.parentNode.getAttribute("data-line");
      let lineQTY = parseInt(this.parentNode.parentNode.parentNode.getAttribute("data-qty"));
      let currentIndexer = i;
      //console.log(linez + lineQTY);
      if (lineQTY == 1) {
        changeItem(linez, currentIndexer);
      } else {
        subtractOneItem(linez, lineQTY, currentIndexer);
      }
    });
  }
};

const renderQuantities = function (cart, selecter) {
  cart.items.forEach(function (item, index) {
    if (selecter == index) {
      //console.log(item);
      let dirtyPrice = item.line_price;
      let roundedPrice = dirtyPrice / 100;
      let formatPrice = roundedPrice.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
      document.querySelectorAll(".c-price")[index].innerHTML = "$ " + formatPrice;
      document.querySelectorAll(".c-quantity span")[index].innerHTML = item.quantity;
    }
  });
};

const updateSubtotal = function () {
  $.ajax({
    type: "GET",
    url: "/cart.js",
    dataType: "json",
    success: function (cart) {
      //onCartUpdate(cart);

      if (cart.item_count === 0) {

      } else {

      }
    },
  });
};

displayCart();
