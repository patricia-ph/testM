var controller = new ScrollMagic.Controller({});

new ScrollMagic.Scene({
  triggerElement: ".sidebar",
  triggerHook: 0,
  offset: -32,
})
  .setClassToggle("header", "black-nav")
  //.addIndicators({ name: "Logo", colorStart: "#A93226" })
  .addTo(controller);

// // Nav
// new ScrollMagic.Scene({
//   triggerElement: ".container",
//   triggerHook: 0,
//   offset: -30,
// })
//   .setClassToggle("header", "black-nav")
//   //.addIndicators({ name: "Nav", colorStart: "#E67E22" })
//   .addTo(controller);
