console.log("Size Guide JS");

let theTables = document.querySelectorAll('.table-group');

let removeCents = function (centIndex) {
  let currentTable = theTables[centIndex].querySelectorAll(".cent");
  currentTable.forEach(function (jtem, j) {
    jtem.classList.remove("active");
  });
};

let removeInches = function (centIndex) {
  let currentTable = theTables[centIndex].querySelectorAll(".inches");
  currentTable.forEach(function (jtem, j) {
    jtem.classList.remove("active");
  });
};

let showCents = function (centIndex) {
  let currentTable = theTables[centIndex].querySelectorAll(".cent");
  currentTable.forEach(function (jtem, j) {
    jtem.classList.add("active");
  });
};

let showInches = function (centIndex) {
  let currentTable = theTables[centIndex].querySelectorAll(".inches");
  currentTable.forEach(function (jtem, j) {
    jtem.classList.add("active");
  });
};

theTables.forEach(function(item, i){

  let centBtn = item.querySelector('.cent-btn')
  let inchesBtn = item.querySelector('.inches-btn');

  centBtn.addEventListener('click', function(event){
    event.preventDefault();
    inchesBtn.classList.remove("active");
    centBtn.classList.add('active');
    removeInches(i);
    showCents(i);
  })

  inchesBtn.addEventListener("click", function (event) {
    event.preventDefault();
    centBtn.classList.remove("active");
    inchesBtn.classList.add("active");
    removeCents(i);
    showInches(i);
  });
});