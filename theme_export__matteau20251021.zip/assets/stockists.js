let stockBtn = document.querySelectorAll('.stockist-btn');
let countries = document.querySelectorAll('.country');

stockBtn.forEach(function(item,i){
  item.addEventListener('click', function(event){
    event.preventDefault();
    setCountry(i);
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0; 
  });
});

let setCountry = function(except){
  countries.forEach(function(item, i){
    if(i == except){
      item.classList.add('active');
      stockBtn[i].classList.add('active');
    } else {
      item.classList.remove('active');
      stockBtn[i].classList.remove("active");
    }
  });
}